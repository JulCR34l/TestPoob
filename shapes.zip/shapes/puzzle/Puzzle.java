package puzzle;
import shapes.*;
import java.util.HashMap;
import javax.swing.JOptionPane;
import java.util.*;

/**
 * Write a description of class Puzzle here.
 * 
 * @author Julián David Castiblanco Real 
 * @version (a version number or a date)
 */
public class Puzzle
{
    private int height;
    private int width;
    private char[][] starting;
    private char[][] ending;
    private char[][] startingClone;
    private char[] glued;
    private Rectangle[][] startingRectangles;
    private Rectangle[][] endingRectangles;
    private boolean isVisible;
    private boolean type;
    private boolean isEditable;
    private boolean[][] positionsGlued;
    public static final Map<String, String> COLORS;

    static {
        COLORS = new HashMap<>();
        COLORS.put("r", "red");
        COLORS.put("b", "blue");
        COLORS.put("g", "green");
        COLORS.put("y", "yellow");
    }
    
    /**
     * Constructor for objects of class Puzzle
     */
    public Puzzle(int h, int w)
    {
        this.height = h;
        this.width = w;
        this.isVisible = false;
        this.starting = new char[h][w];
        this.glued = new char[4];
        this.startingRectangles = new Rectangle[h][w];
        this.endingRectangles = new Rectangle[h][w];
        this.isVisible = false;
        this.type = false;
        this.isEditable = true;
        this.positionsGlued = new boolean[h][w];
        initializeRectangles(type);
    }
    
    /**
     * Constructor for objects of class Puzzle
     */
    public Puzzle(char[][] ending)
    {
        this(ending.length, ending[0].length);
        this.ending = ending;
        this.type = true;
        initializeRectangles(type);
    }
    
    /**
     * Constructor for objects of class Puzzle
     */
    public Puzzle(char[][] starting, char[][] ending)
    {
        this(ending);
        this.starting = starting;
        this.startingClone = starting;
        this.isEditable = true;
        if(starting.length != ending.length && starting[0].length != ending[0].length){
            System.out.println("Las dimensiones de starting y ending tienen que ser iguales.");
        }
        initializeRectangles(type);     
    }
    
    /**
     *   
     */
    public void addTile(int row, int column, String color)
    {   
        if (isPositionValid(row, column) && starting[row][column] == '\0'){
            if(color != null){
                char newColor = color.charAt(0);
                starting[row][column] = newColor;
                if(isVisible){
                    makeVisible();
                }
            }
        }
    }
    
    /**
     *   
     */
    public void deleteTile(int row, int column){
        if (isPositionValid(row, column) && starting[row][column] != '\0'){
            starting[row][column] = '\0';
            if(isVisible){
                startingRectangles[row][column].changeColor("black");
                makeVisible();
            }
        }
    }
    
    /**
     *   
     */
    public void relocateTile(int[] from, int[] to){
        if (starting[to[0]][to[1]] != 'H' && starting[from[0]][from[1]] != 'H') {
            String colorToChange = (String.valueOf(starting[from[0]][from[1]]));
            deleteTile(from[0], from[1]);
            addTile(to[0], to[1], colorToChange);
        } else if(starting[to[0]][to[1]] == 'H'){
            deleteTile(from[0], from[1]);
        }
    }
    
    /**
     * Fix the tile and if the board moves, it will not move   
     */
    public void addGlue(int row, int column) {
    if (!isPositionValid(row, column) || starting[row][column] == '\0') {
        return; // Invalid position or empty tile
    }

    positionsGlued[row][column] = true;

    for (int[] direction : new int[][]{{1, 0}, {0, 1}, {-1, 0}, {0, -1}}) {
        int newRow = row + direction[0];
        int newCol = column + direction[1];

        if (isPositionValid(newRow, newCol) && starting[newRow][newCol] != '\0') {
            positionsGlued[newRow][newCol] = true;
        }
    }
}
    
    /**
     * 
     */
    public void deleteGlue(int row, int column){
        
    }
    
    /**
     * 
     */
    public void makeHole(int row, int column){
        if(isPositionValid(row,column) && starting[row][column] == '\0'){
            starting[row][column] = 'H';
            startingRectangles[row][column].changeColor("white");
        }
    }
    
    /**
     * 
     */
    public void tilt(char direction) {
        int row = starting.length;
        int column = starting[0].length;
    
        switch(direction) {
            case 'U':
                moveGame(column, row, column, -1, 0, 'Y');
                break;
            case 'D':
                moveGame(column, row, column, 1, 0, 'Y');
                break;
            case 'R':
                moveGame(row, row, column, 0, 1, 'X');
                break;
            case 'L':
                moveGame(row, row, column, 0, -1, 'X');
                break;
            default:
                System.out.println("Valor inválido");
        }
    }
    
    /**
     * 
     */
    public void tilt(){
        char[] directions = {'U','D','R','L'};
        for(char direction : directions){
            
        }
    }
    
    /**
     * 
     */
    public void exchange() {
        makeInvisible();
        // Intercambiar las referencias de starting y ending
        char[][] temp = starting;
        starting = ending;
        ending = temp;
        // También intercambiar las referencias de los rectángulos visuales
        Rectangle[][] tempRectangles = startingRectangles;
        startingRectangles = endingRectangles;
        endingRectangles = tempRectangles;
    
        for (int i = 0; i < startingRectangles.length; i++) {
            for (int j = 0; j < startingRectangles[0].length; j++) {
                if (startingRectangles[i][j] != null && endingRectangles[i][j] != null) {
                    // Obtener la posición del rectangulo que se puede editar
                    int tempX = startingRectangles[i][j].getX();
                    int tempY = startingRectangles[i][j].getY();
                    
                    // Intercambiar las posiciones de los rectángulos que se esta ditando al de referencia 
                    startingRectangles[i][j].setPosition(endingRectangles[i][j].getX(), endingRectangles[i][j].getY());
                    endingRectangles[i][j].setPosition(tempX, tempY);
                }
            }
        }
        
        makeVisible();
    }
    
    /**
     *   
     */
    public void makeVisible()
    {
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                confirmRectangle(starting, startingRectangles, i, j);
                confirmRectangle(ending, endingRectangles, i, j);
            }
        }
        isVisible = true;
    }
    
    /**
     *   
     */
    public void makeInvisible()
    {
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                startingRectangles[i][j].makeInvisible();
                if (endingRectangles[i][j] != null) {
                    endingRectangles[i][j].makeInvisible();
                }
            }
        }
        isVisible = false;
    }
    
    /**
     * 
     */
    public void finish(){
        makeInvisible();
    
        starting = null;
        ending = null;
        startingRectangles = null;
        endingRectangles = null;
    
        System.out.println("El simulador ha terminado.");
        System.exit(0); // Esto finalizaría el programa
    }
    
    private void moveGame(int orientation, int row, int column, int yWay, int xWay, char axis) {
        int count = 0;
        while (count != orientation) {
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < column; j++) {
                    if (axis == 'Y' 
                        && (starting[i][j] == '\0'
                        || starting[i][j] == 'H')
                        && i - yWay >= 0
                        && i - yWay < row
                        && starting[i - yWay][j] != '\0') {
                        int[] from = {i - yWay, j};
                        int[] to = {i, j};
                        relocateTile(from, to);
                    } else if (axis == 'X' 
                        && (starting[i][j] == '\0'
                        || starting[i][j] == 'H')
                        && j - xWay >= 0
                        && j - xWay < column
                        && starting[i][j - xWay] != '\0') {
                        int[] from = {i, j - xWay};
                        int[] to = {i, j};
                        relocateTile(from, to);
                    }
                }
            }
            count++;
        }
    }
    
    private void confirmRectangle(char[][] matriz, Rectangle[][] matrizRectangles, int i, int j){
        if(matrizRectangles[i][j] != null){
            String color = COLORS.get(String.valueOf(matriz[i][j]));
            if (color != null){
                matrizRectangles[i][j].changeColor(color);
            }
            matrizRectangles[i][j].makeVisible();
        }
    }
    
    private void correctMatriz(char[][] matriz){
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                if(matriz[i][j] == '.'){
                    matriz[i][j] = '\0';
                    }
            }
        }
    }

    private void initializeRectangles(boolean type){ //true = start/ending     false = starting
        int rectHeight = 40;
        int rectWidth = 40;
        int xOffset = 160;
        int yOffset = 360;
        int spacing = 3;
        if(!type){
            creatingRectangles(starting, startingRectangles, rectHeight, rectWidth, xOffset, yOffset, spacing);
        } else {
            creatingRectangles(ending, endingRectangles, rectHeight, rectWidth, xOffset * 3, yOffset, spacing);
            creatingRectangles(starting, startingRectangles, rectHeight, rectWidth, xOffset, yOffset, spacing);
        }
    }
    
    private void creatingRectangles(char[][] matriz, Rectangle[][] rectangles,int rectHeight, int rectWidth, int xOffset, int yOffset, int spacing){
        for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    int xPosition = xOffset + j * (rectWidth + spacing); // Calcular la posición X
                    int yPosition = yOffset + i * (rectHeight + spacing); // Calcular la posición Y
                    correctMatriz(matriz);
                    if(matriz[i][j] !=  '.'){
                        rectangles[i][j]=new Rectangle(rectHeight,rectWidth,xPosition,yPosition,
                        String.valueOf(matriz[i][j]));
                    }
                }
            }
    }
    
    private boolean isPositionValid(int row, int column){
        return  row >=0 && row < width && column >= 0 && column < height;
    }
}
